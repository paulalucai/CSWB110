/* Paula Caixeta; CSCI 112; online class */
#include <stdio.h>

/* wk5ex2.c: conversion table of ft to m */
void main(void) {
	//vars
	int ft;
	double m;
	
	//headers
	printf("Feet  |  Meters\n");
	printf("_______________\n");
	
	//conversion
	for (ft = 3; ft <= 30; ++ft) {
		m = ft / 3.28;
		printf("%d  |  %.2f\n", ft, m);
	}
}
