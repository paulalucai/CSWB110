/* Paula Caixeta; CSCI 112; online class */
#include <stdio.h>

/* wk5ex4.c: Calculate running average */
void main(void) {
	//vars
	int num, count;
	double sum;
	
	//prompt
	printf("Enter an integer or -9999 to quit: ");
	scanf("%d", &num);
	
	//loop
	count = 0;
	sum = 0.0;
	while (num != -9999) {
		count++;
		sum += num;
		printf("The average so far is %.1f\n", sum / count);
		
		printf("Enter an integer or -9999 to quit: ");
		scanf("%d", &num);
	}
}
