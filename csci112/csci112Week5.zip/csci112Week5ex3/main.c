/* Paula Caixeta; CSCI 112; online class */
#include <stdio.h>

/* wk5ex3.c: find maximum of 5 numbers */
void main(void) {
	
	//vars
	int array[5], i, num, max;
 
	//prompt
	printf("\nEnter number of elements (up to 5): ");
	scanf("%d", &num);
	printf("Now enter each number and hit 'return/enter': ");
 
	//read n elements in an array
	for (i = 0; i < num; i++)
		scanf("%d", &array[i]);
 
	//set first element to maximum
	max = array[0];
 
	//loop
	for (i = 0; i < num; i++) {
		if (array[i] > max) {
			max = array[i];
		}
	}
 
	//output
	printf("\nLargest Number : %d", max);
}