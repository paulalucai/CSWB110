/* Paula Caixeta; CSCI 112; online class */
#include <stdio.h>

/* wk5ex5.c: output reverse right triangle number pattern */
void main(void) {
	//vars
	int rows, items;
	
	//loop
	for (rows = 9; rows >= 1; rows--) {
		for (items = 1; items <= rows; items++) {
			printf("%d", items);
		}
		printf("\n");
	}
}
