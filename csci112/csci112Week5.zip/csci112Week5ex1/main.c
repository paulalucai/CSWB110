/* Paula Caixeta; CSCI 112; online class */
#include <stdio.h>

/* wk5ex1.c: simple series */
void main(void)
{
	int num, count;
	
	printf("Enter number: ");
	scanf("%d", &num);
	
	for (count = 1; count < 7; ++count) {
		num += 3;
		printf("%d, ", num);
	}
	printf("%d Done!\n", num + 3);
}
